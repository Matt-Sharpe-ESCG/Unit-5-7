
USS ENTERPRISE NCC-1701-D

Galaxy class starship, under the command of Jean-Luc Picard.

Conditions of use:

Please put credits on the images made with this mesh, something like "Enterprise-D by David Metlesits", or similar.
You may use this mesh for any non-profit work.
You may edit, kitbash or do anything with this mesh. Just have fun with it :D

Live long and prosper!


David "KnightRider" Metlesits

